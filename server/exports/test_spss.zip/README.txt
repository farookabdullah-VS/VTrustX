SPSS Export Package for Customer Satisfaction Survey
============================================================

Generated: 2026-01-23T03:35:54.875Z
Total Responses: 3

Files Included:
- data.csv: Survey response data in CSV format
- import_syntax.sps: SPSS syntax file for importing and analyzing data
- README.txt: This file

Instructions:
1. Open SPSS Statistics
2. Open the import_syntax.sps file
3. Run the syntax file (Run > All)
4. The data will be imported and labeled automatically

Note: Make sure data.csv is in the same directory as the syntax file.
